// kaldi-decoder/csrc/lattice-faster-decoder.cc

// Copyright 2009-2012  Microsoft Corporation  Mirko Hannemann
//           2013-2018  Johns Hopkins University (Author: Daniel Povey)
//                2014  Guoguo Chen
//                2018  Zhehuai Chen
// Copyright (c)  2023  Xiaomi Corporation

// this file is copied and modified from
// kaldi/src/decoder/lattice-faster-decoder.cc

#include "kaldi-decoder/csrc/lattice-faster-decoder.h"
namespace kaldi_decoder {}
