// Windows-specific OpenFst config file
// No dynamic registration.
#define FST_NO_DYNAMIC_LINKING 1
