Convert FST from k2 to OpenFst
==============================

This section describes how to convert an FST from `k2`_ to `OpenFst`_.

.. toctree::

   convert-acceptor
   convert-transducer
